using CustomEelementSample01.Data;
using CustomEelementSample01.Pages;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor(option => option.RootComponents.RegisterCustomElement<Counter>("my-counter"));
builder.Services.AddSingleton<WeatherForecastService>();

builder.Services.AddCors(option =>
{
    option.AddPolicy("NewPolicy", builder =>
        builder.AllowAnyMethod()
            .AllowCredentials()
            .SetIsOriginAllowed((host) => true)
            .AllowAnyHeader());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}


app.UseStaticFiles();

app.UseRouting();
app.UseCors("NewPolicy");

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
